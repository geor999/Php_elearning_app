<?php
session_start();
include_once '../connect.php';

if (isset($_POST['submit'])) {
    if ($_POST['submit'] == "upload") {
        $text = $_POST['text'];
        $description = $_POST['description'];
        $today = date("Y/m/d");

        $sql = "INSERT INTO `announcements`(`id`, `date`, `subject`, `text`) VALUES (NULL,'$today','$description','$text');";
        if (mysqli_query($conn, $sql)) {
            header("Location: ../announcement.php?annadd=true");
            exit();
        }
    }
    else if ($_POST['submit'] == "update") {
        $id = $_POST['id'];
        $text = $_POST['text'];
        $subject = $_POST['description'];
        $date = date("Y/m/d");

        $sql = "UPDATE `announcements` SET `id`='$id', `date`='$date', `subject`='$subject', `text`='$text' WHERE `id`='$id';";
        if (mysqli_query($conn, $sql)) {
            header("Location: ../announcement.php?annupd=true");
            exit();
        }
}
else if($_POST['submit'] == "delete")
    {
        $id = $_POST['id'];
            $sql = "DELETE FROM `announcements` WHERE `id`='$id'";
            if (mysqli_query($conn, $sql)) {
                header("Location: ../announcement.php?anndel=true");
                exit();
            }
        }
    }
?>