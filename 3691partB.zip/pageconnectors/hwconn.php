<?php
session_start();
include_once '../connect.php';

if (isset($_POST['submit'])) {
    if ($_POST['submit'] == "upload") {
        $goals = $_POST['goal1'];
        if (isset($_POST['goal2']) && $_POST['goal2'] !== "") {
            $goals = $_POST['goal1'] . "-" . $_POST['goal2'];
            if (isset($_POST['goal3']) && $_POST['goal3'] !== "") {
                $goals = $_POST['goal1'] . "-" . $_POST['goal2'] . "-" . $_POST['goal3'];
                if (isset($_POST['goal4']) && $_POST['goal4'] !== "") {
                    $goals = $_POST['goal1'] . "-" . $_POST['goal2'] . "-" . $_POST['goal3'] . "-" . $_POST['goal4'];
                }
            }

        }
        $deliverables = $_POST['deliverable1'];
        if (isset($_POST['deliverable2']) && $_POST['deliverable2'] !== "") {
            $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'];
            if (isset($_POST['deliverable3']) && $_POST['deliverable3'] !== "") {
                $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'] . "-" . $_POST['deliverable3'];
                if (isset($_POST['deliverable4']) && $_POST['deliverable4'] !== "") {
                    $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'] . "-" . $_POST['deliverable3'] . "-" . $_POST['deliverable4'];
                }
            }

        }
        $deadline = $_POST['deadline'];

        $docname = $_FILES["docfile"]["name"];
        $accept = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($docname, PATHINFO_EXTENSION));
        if (in_array($ext, $accept)) {
            if (move_uploaded_file($_FILES["docfile"]["tmp_name"], '../uploads/' . $docname)) {
                $sql = "INSERT INTO `homework`(`id`, `goals`, `name`, `deliverables`, `deadline`) VALUES (NULL,'$goals','$docname','$deliverables','$deadline');";
                mysqli_query($conn, $sql);

                $sql = "SELECT * from homework";

                if ($result = mysqli_query($con, $sql)) {

                    $rowcount = mysqli_num_rows($result);

                    printf("Total rows in this table : %d\n", $rowcount);
                }

                $today = date("Y/m/d");
                $theme = "Υποβλήθηκε η εργασία " . $rowcount;
                $text = "Η ημερομηνία παράδοσης της εργασίας είναι " . $deadline;
                $sql = "INSERT INTO `announcements`(`id`, `date`, `subject`, `text`) VALUES (NULL,'$today','$theme','$text');";
                mysqli_query($conn, $sql);
                header("Location: ../homework.php?addition=true");
                exit();
            } else {
                echo "Το αρχείο που δώσατε δεν ήταν της κατάλληλης μορφής!";
            }
        }
    } else if ($_POST['submit'] == "update") {
        $id = $_POST['id'];
        $goals = $_POST['goal1'];
        if (isset($_POST['goal2']) && $_POST['goal2'] !== "") {
            $goals = $_POST['goal1'] . "-" . $_POST['goal2'];
            if (isset($_POST['goal3']) && $_POST['goal3'] !== "") {
                $goals = $_POST['goal1'] . "-" . $_POST['goal2'] . "-" . $_POST['goal3'];
                if (isset($_POST['goal4']) && $_POST['goal4'] !== "") {
                    $goals = $_POST['goal1'] . "-" . $_POST['goal2'] . "-" . $_POST['goal3'] . "-" . $_POST['goal4'];
                }
            }

        }
        $deliverables = $_POST['deliverable1'];
        if (isset($_POST['deliverable2']) && $_POST['deliverable2'] !== "") {
            $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'];
            if (isset($_POST['deliverable3']) && $_POST['deliverable3'] !== "") {
                $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'] . "-" . $_POST['deliverable3'];
                if (isset($_POST['deliverable4']) && $_POST['deliverable4'] !== "") {
                    $deliverables = $_POST['deliverable1'] . "-" . $_POST['deliverable2'] . "-" . $_POST['deliverable3'] . "-" . $_POST['deliverable4'];
                }
            }

        }
        $deadline = $_POST['deadline'];

        $docname = $_FILES["docfile"]["name"];
        $accept = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($docname, PATHINFO_EXTENSION));
        if (in_array($ext, $accept)) {
            if (move_uploaded_file($_FILES["docfile"]["tmp_name"], '../uploads/' . $docname)) {
                $sql = "UPDATE `homework` SET `id`='$id', `goals`='$goals', `name`='$docname', `deliverables`='$deliverables', `deadline`='$deadline' WHERE `id`='$id';";
                mysqli_query($conn, $sql);

                $sql = "SELECT * from homework";

                if ($result = mysqli_query($con, $sql)) {

                    $rowcount = mysqli_num_rows($result);

                    printf("Total rows in this table : %d\n", $rowcount);
                }

                $today = date("Y/m/d");
                $theme = "Υποβλήθηκε τροποποίηση εργασίας " . $rowcount;
                $text = "Η ημερομηνία παράδοσης της εργασίας είναι " . $deadline;
                $sql = "INSERT INTO `announcements`(`id`, `date`, `subject`, `text`) VALUES (NULL,'$today','$theme','$text');";
                mysqli_query($conn, $sql);
                header("Location: ../homework.php?hwupdate=true");
            }
        }

    }
    else if ($_POST['submit'] == "delete")
    {
        $id = $_POST['id'];
            $sql = "DELETE FROM `homework` WHERE `id`='$id'";
            if (mysqli_query($conn, $sql)) {
                header("Location: ../homework.php?hwremove=true");
                exit();
            }
        }
    }
?>