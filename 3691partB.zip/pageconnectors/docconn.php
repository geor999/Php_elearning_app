<?php
session_start();
include_once '../connect.php';

if (isset($_POST['submit'])) {
    if ($_POST['submit'] == "upload") {
        $title = $_POST['title'];
        $description = $_POST['description'];

        $docname = $_FILES["docfile"]["name"];
        $accept = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($docname, PATHINFO_EXTENSION));
        if (in_array($ext, $accept)) {
            if (move_uploaded_file($_FILES["docfile"]["tmp_name"], '../uploads/' . $docname)) {
                $sql = "INSERT INTO `documents`(`id`, `doc_title`, `doc_subject`, `doc_name`) VALUES (NULL,'$title','$description','$docname');";
                if (mysqli_query($conn, $sql)) {
                    header("Location: ../documents.php?docadd=true");
                    exit();
                }
            }
        }
    }
    else if($_POST['submit'] == "update")
    {
        $id = $_POST['id'];
        $description = $_POST['description'];
        $title = $_POST['title'];

        $docname = $_FILES["docfile"]["name"];
        $accept = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($docname, PATHINFO_EXTENSION));
        if (in_array($ext, $accept)) {
            if (move_uploaded_file($_FILES["docfile"]["tmp_name"], '../uploads/' . $docname)) {
                $sql = "UPDATE `documents` SET `id`='$id',`doc_title`='$title',`doc_subject`='$description',`doc_name`='$docname' WHERE `id`='$id';";
                if (mysqli_query($conn, $sql)) {
                    header("Location: ../documents.php?docupdate=true");
                    exit();
                }
            }
        }



    }
    else if($_POST['submit'] == "delete")
    {
        $id = $_POST['id'];
            $sql = "DELETE FROM `documents` WHERE `id`='$id'";
            if (mysqli_query($conn, $sql)) {
                header("Location: ../documents.php?docdel=true");
                exit();
            }
        }
    }
?>