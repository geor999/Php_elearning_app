<?php
session_start();
include_once '../connect.php';

if (isset($_POST['submit'])) {
    if ($_POST['submit'] == "upload") {
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $email = $_POST['loginame'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        $sql = "INSERT INTO `users`(`id`, `name`, `surname`, `loginame`, `password`, `role`) VALUES (NULL,'$name','$surname','$email','$password','$role');";
        if (mysqli_query($conn, $sql)) {
            header("Location: ../creators/userhandl.php?addition=true");
            exit();
        }
    } else {
        if ($_POST['submit'] == "update") {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $surname = $_POST['surname'];
            $email = $_POST['loginame'];
            $password = $_POST['password'];
            $role = $_POST['role'];

            $sql = "UPDATE `users` SET `id`='$id',`name`='$name',`surname`='$surname',`loginame`='$email',`password`='$password',`role`='$role' WHERE `id`='$id';";
            if (mysqli_query($conn, $sql)) {
                header("Location: ../creators/userhandl.php?update=true");
                exit();
            }
        } else if ($_POST['submit'] == "delete") {
            $id = $_POST['id'];
            $sql = "DELETE FROM `users` WHERE `id`='$id'";
            if (mysqli_query($conn, $sql)) {
                header("Location: ../creators/userhandl.php?remove=true");
                exit();
            }
        }
    }
}
?>