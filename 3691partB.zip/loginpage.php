<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="loginpage.css" />
</head>

<body>
  <div class="main">
    <form action="login.php" method="post">
      <div class="form" >
        <?php
        if (isset($_GET["logout"])) {
          if ($_GET['logout'] == 'true') {
            echo "<p class='p'>You were disconnected succesfully</p>";
          } 
        }
        if (isset($_GET['error'])) {
          if ($_GET['error'] == "emailfalse") {
            echo "<p class='p'>The email you gave is incorrect!</p>";
          } else if ($_GET['error'] == "passfalse") {
            echo "<p class='p'>The password you gave is incorrect!</p>";
          } else if ($_GET['error'] == "Name or Password is incorrect!") {
            echo "<p class='p'>The name/password combination you gave is incorrect!</p>";
          }
        }
        ?>
        <input class="input" type="text" placeholder="Your academic email" name="loginame" required>

        <input class="input" type="password" placeholder="Enter Password" name="pass" required>

        <button class="btn" type="submit" name="sub_btn">Login</button>
      </div>
    </form>
  </div>
</body>

</html>