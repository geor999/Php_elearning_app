<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Αρχική Σελίδα</title>
  <link rel="stylesheet" href="index.css" />
  <link rel="stylesheet" href="logoutbtn.css" />
  <link rel="stylesheet" href="common\basicui.css" />
  <link rel="stylesheet" href="header\header.css" />
  <link rel="stylesheet" href="topbutton\top.css" />
  <script src="header\header.js"></script>
  <script src="topbutton\top.js"></script>
  <script src="common\basicscript.js"></script>
</head>

<body class="body">
  <a id="top"></a>
  <?php
  if (isset($_POST['logout'])) {
    header("location: logout.php");
    exit();
  } else {
    session_start();
    if (!isset($_SESSION["loginame"])) {
      header("location: loginpage.php");
      exit();
    }
  }
  ?>
  <div class="page-name">
    <div class="jsscript">
      <div class="container" onclick="menuchangeonclick(this,'navigation-section')">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
    </div>
    <h1 class="title">Αρχική Σελίδα</h1>
    <?php if (isset($_SESSION["loginame"])) { ?>
      <a id="nav-a">
        <?php echo ($_SESSION['name'] . " " . $_SESSION['surname']); ?>
      </a>
    <?php } ?>
  </div>
  <div class="full-section">
    <section id="navigation-section">
      <?php include('header/header.php'); ?>
    </section>
    <section class="info-section">
      <h4 class="info-title">Καλωσορίσατε στο μάθημα Web Development!</h4>
      <?php
      if (isset($_GET['loggedin'])) {
        if ($_GET['loggedin'] == 'successful') {
          echo 'Logged In successfully!';
        }
      }
      ?>
      <p class="info">
        Σε αυτό το μάθημα θα μάθετε να χρησιμοποιείτε HTML/CSS/JS για την
        συγγραφή ενδιαφέρον και χρήσιμων web apps από το μηδέν. Ενημερώσεις
        για το μάθημα και τις διαλέξεις καθώς και ανακοινώσεις του διδάσκοντα
        μπορούμε να δούμε στην σελίδα
        <a href="announcement.php">Ανακοινώσεις</a>. Εκφωνήσεις εργασιών
        εφόσον έχουν ανακοινωθεί στις Ανακοινώσεις μπορούμε να βρούμε στις
        <a href="homework.php">Εργασίες</a> καθώς και τις διάφανιες του
        μαθήματος ενώ ταυτόχρονα και άλλο εκπαιδευτικό υλικό στα
        <a href="documents.php">Έγγραφα μαθήματος.</a> Τέλος για οποιοδήποτε
        πρόβλημα προκύψει είτε με εργασίες είτε κατά την διάρκεια της χρονιάς
        μπορείτε να επικοινωνήσετε με τον διδάσκοντα στην σελίδα
        <a href="communication.php">Επικοινωνία.</a>
        <br />
      </p>
      <img src="files\photo.jpeg" width="20%" class="info-centered-image" />
      <div id="footer">
        <div id="topbutton">
          <?php include('topbutton/top.php'); ?>
        </div>
      </div>
    </section>
  </div>

</body>

</html>