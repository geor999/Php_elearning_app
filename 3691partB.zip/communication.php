<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Επικοινωνία</title>
  <link rel="stylesheet" href="communication.css" />
  <link rel="stylesheet" href="logoutbtn.css" />
  <link rel="stylesheet" href="common\basicui.css" />
  <link rel="stylesheet" href="header\header.css" />
  <link rel="stylesheet" href="topbutton\top.css" />
  <script src="header\header.js" defer></script>
  <script src="topbutton\top.js" defer></script>
  <script src="common\basicscript.js" defer></script>
</head>

<body class="body">
  <a id="top"></a>
  <?php
  if (isset($_POST['logout'])) {
    header("location: logout.php");

  } else {
    session_start();
    if (!isset($_SESSION["loginame"])) {
      header("location: loginpage.php");
    }
  }
  ?>
  <div class="page-name">
    <div class="jsscript">
      <div class="container" onclick="menuchangeonclick(this,'navigation-section')">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
    </div>
    <h1 class="title">Επικοινωνία</h1>
    <?php if (isset($_SESSION["loginame"])) { ?>
      <a id="nav-a">
        <?php echo ($_SESSION['name'] . " " . $_SESSION['surname']); ?>
      </a>
    <?php } ?>
  </div>
  <div class="full-section">
    <div id="navigation-section">
      <?php include('header/header.php'); ?>
    </div>
    <div class="info-section">
      <div class="info">
        <div class="com">
          <h2 style="color: green;">Αποστολή e-mail μέσω web φόρμας<br></h2>
          <form action="email.php" method="POST">
            <input type="email" name='sender' placeholder="Αποστολέας(Email)" ></input><br>
            <input type="text" name='subject' placeholder="Θέμα"></input><br>
            <div class="button">
              <textarea class="textholder" type="text" name='text' placeholder="Κείμενο"
                style="width: 200px; height: 150px;"></textarea>
              <button type='submit' value='update' name='email' class='updatebtn' style="margin-left: 7.5%;">Send</button>
            </div>
          </form>
        </div>
        <div class="com">
          <h2 style="color: green;">Αποστολή e-mail με χρήση e-mail διεύθυνσης<br></h2>
          <p>Εναλλακτικά μπορείτε να αποστείλετε e-mail στην παρακάτω διεύθυνση ηλεκτρονικού ταχυδρομείου <a
              href="mailto:georganti@csd.auth.gr">tutor@csd.auth.test.gr</a><br></p>
        </div>
      </div>
      <div id="footer">
        <div id="topbutton">
          <?php include('topbutton/top.php'); ?>

        </div>
      </div>
    </div>
  </div>
  </div>
</body>

</html>