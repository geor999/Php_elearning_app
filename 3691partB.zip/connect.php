<?php

$serverName = "webpagesdb.it.auth.gr";
$userName = "georganti";
$password = "12345678a";
$dBName = "student3691partB";

$conn = mysqli_connect($serverName,$userName,$password,$dBName,"3306");

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}
?>