<?php session_start();
require_once 'connect.php';

if(isset($_POST['loginame']) && isset($_POST['pass']))
{
    function valid($info)
    {
        #stemming
        $info=htmlspecialchars(stripslashes(trim($info)));
        return $info;
    }
}

$loginame = valid($_POST['loginame']);
$pass = valid($_POST['pass']);

if(empty($loginame))
{
  header("Location: loginpage.php?error=emailfalse");
  exit();
}
if(empty($pass))
{
  header("Location: loginpage.php?error=passfalse");   
  exit();
}

$sql = "SELECT * FROM users WHERE loginame='$loginame' AND password='$pass'";
$query = mysqli_query($conn,$sql);
if(mysqli_num_rows($query)===1)
{
    $grammi = mysqli_fetch_assoc($query);
    if($grammi['loginame'] === $loginame && $grammi['password']=== $pass )
    {
        echo "Logged in.";
        $_SESSION['loginame'] = $grammi['loginame'];
        $_SESSION['password'] = $grammi['password'];
        $_SESSION['id'] = $grammi['id'];
        $_SESSION['role'] = $grammi['role'];
        $_SESSION['name'] = $grammi['name'];
        $_SESSION['surname'] = $grammi['surname'];
        header("Location: index.php?loggedin=successful");
        exit();
    }

}
else 
{
header("Location: loginpage.php?error=Name or Password is incorrect!");
exit(); 
}
?>