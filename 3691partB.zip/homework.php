<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Εργασίες</title>
  <link rel="stylesheet" href="homework.css" />
  <link rel="stylesheet" href="logoutbtn.css" />
  <link rel="stylesheet" href="common\basicui.css" />
  <link rel="stylesheet" href="header\header.css" />
  <link rel="stylesheet" href="topbutton\top.css" />
  <script src="header\header.js" defer></script>
  <script src="topbutton\top.js" defer></script>
  <script src="common\basicscript.js" defer></script>
</head>

<body class="body">
  <a id="top"></a>
  <?php

  if (isset($_POST['logout'])) {
    header("location: logout.php");

  } else {
    session_start();
    if (!isset($_SESSION["loginame"])) {
      header("location: loginpage.php");
    }
  }
  ?>
  <div class="page-name">
    <div class="jsscript">
      <div class="container" onclick="menuchangeonclick(this,'navigation-section')">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
    </div>
    <h1 class="title">Εργασίες</h1>
    <?php if (isset($_SESSION["loginame"])) { ?>
      <a id="nav-a">
        <?php echo ($_SESSION['name'] . " " . $_SESSION['surname']); ?>
      </a>
    <?php } ?>
  </div>
  <div class="full-section">
    <section id="navigation-section">
      <?php include('header/header.php'); ?>
    </section>
    <section class="info-section">
      <?php
      include_once "connect.php";
      if (isset($_SESSION["loginame"])) {
        if ($_SESSION['role'] === 'tutor') {
          echo "<div class='hw'>
            <h2 style='color: green;''>Ανάρτησε μια νέα εργασία πατώντας <a style='color: blue;'
                href='creators/newhw.php'>εδώ.</a></h1>
          </div>
          <hr/>";
        }
      }
      $query = "SELECT * FROM `homework`";
      $result = $conn->query($query);
      $t = 0;
      while ($grammh = $result->fetch_assoc()) {
        $t += 1;
        $id = $grammh['id'];
        $goals = $grammh['goals'];
        $name = $grammh['name'];
        $deliverables = $grammh['deliverables'];
        $deadline = $grammh['deadline'];

        $goalsarray = str_split($goals);
        $appendable = "<li>";
        foreach ($goalsarray as $char) {
          if ($char != '-') {
            $appendable .= $char;
          } else {
            $appendable .= "</li><li>";
          }
        }
        $goals1 = $appendable . "</li>";
        $deliverablesarray = str_split($deliverables);
        $appendable = "<li>";
        foreach ($deliverablesarray as $char) {
          if ($char != '-') {
            $appendable .= $char;
          } else {
            $appendable .= "</li><li>";
          }
        }
        $deliverables1 = $appendable . "</li>";

        echo "<div class='hw'>
        <h2 style='color: green;'>Εργασία $t</h2>
        <div class='info-hw'>
          <p>
            Στόχοι: Οι στόχοι τις εργασίας είναι
          <ol>$goals1
          </ol>
          Εκφώνηση:<br>
          &emsp; &emsp; Κατεβάστε την εκφώνηση της εργασίας από <a href='uploads/$name' download>εδώ</a> <br>
          Παραδοτέα:
          &emsp; &emsp; &emsp;
          <ol>
            $deliverables1
          </ol>
          Ημερομηνία παράδοσης: $deadline
        </div>
      </div>";
      if ($_SESSION['role'] === 'tutor') {
        echo "<div class='buttons'>
                <form action='creators/newhw.php' method='POST' enctype='multipart/form-data'>
                <input type='hidden' value='$id' name='id' required />
                <input type='hidden' value='$goals' name='date' required />
                <input type='hidden' value='$deliverables' name='subject' required />
                <input type='hidden' value='$name' name='text' required />
                <input type='hidden' value='$deadline' name='text' required />
                <button type='submit' value='update' name='submit' class='updatebtn' >Update</button>
                </form>
                <form action='pageconnectors/hwconn.php' method='POST' enctype='multipart/form-data'>
                <input type='hidden' value='$id' name='id' required />
                <button type='submit' value='delete' name='submit' class='deletebtn' >Delete</button>
                </form>
                </div>";
      }
      } ?>
  <div id="footer">
    <div id="topbutton">
      <?php include('topbutton/top.php'); ?>
    </div>
  </div>
  </section>
  </div>

</body>

</html>