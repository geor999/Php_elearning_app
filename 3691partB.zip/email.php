<?php
session_start();
include_once '../connect.php';

if (isset($_POST['email'])) {
    if ($_POST['email'] == "update") {
        $sender = $_POST['sender'];
        $headers = "From:$sender" ;
        $text = $_POST['text'];
        $subject = $_POST['subject'];
        $to='georganti@csd.auth.gr';
        if (mail($to, $subject, $text, $headers)) {
            header("Location: communication.php?addition=$headers + 1");
            exit();
        }
        else{
            header("Location: communication.php?addition=$headers");
            exit();
        }
    }
}
?>