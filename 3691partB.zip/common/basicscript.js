let menuState;
let icon;
function menuchangeonclick(a, y) {
    var namebar=document.querySelector(".page-name");
    var x = window.matchMedia("(max-width: 600px)");
    var nav = document.querySelector("#navigation-section");
    var resizingnav=document.querySelector('.resizing-nav');
    if (x.matches) {
        a.classList.toggle("change");
        if(menuState==undefined)
        {
            menuState='closed';
        }
            var infosec = document.querySelector(".info-section");
            if (infosec.style.display == "none") {
                infosec.style.display = "block"
                nav.style.display = "none";
                nav.style.width="10%";
                menuState = 'closed';
            }
            else {
                infosec.style.display = "none";
                nav.style.display = "block ";
                nav.style.width="100%";    
                console.log("mphka edw pera");
                resizingnav.style.display="block";
                menuState = 'open';
            }
        }
        console.log(menuState);
}


function changefun(t)
{
    var nav = document.querySelector("#navigation-section");
    var resizingnav=document.querySelector('.resizing-nav');
    var a = document.querySelector(".jsscript");
    var infosec = document.querySelector(".info-section");

    if(t)
    {   if(menuState==undefined)
        {
            menuState='closed';
        }
        if(menuState=='open')
        {
            infosec.style.display = "block"
            nav.style.display = "none";
            nav.style.width="30%";
            menuState = 'closed';
            console.log("mphka edw 3");
            a.classList.toggle("change");
        }
        else
        {
            console.log("mphka edw 2");
            console.log(menuState);
            menuState = 'closed';
        }
        
    }
    else
    {
        if(menuState==undefined)
        {
            menuState='open';
        }
        if(menuState=='open')
        {
        infosec.style.display = "block"
        nav.style.display = "none";
        a.classList.toggle("change");
        menuState = 'closed';
        console.log("mphka edw");
        a.classList.toggle("change");
        }
        else{
            console.log("mphka edw 4");
            console.log(menuState);
            a.classList.toggle("change");
            menuState='open';
        }
    }
}
var q=window.matchMedia("(max-width: 600px)");
console.log(q);
q.onchange=(e=>changefun(q.matches))
