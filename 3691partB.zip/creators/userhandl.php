<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="newwhw.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Διαχείριση Χρηστών</title>
</head>

<body>
<?php
        session_start();
        if (!isset($_SESSION["loginame"])){
          header("location: ..\loginpage.php");
        }
    ?>
    <h2 id="top">Λίστα με χρήστες</h2>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email(loginame)</th>
                <th>Password</th>
                <th>Role</th>
            </tr>
        </thead>

        <?php
        include_once "../connect.php";

        if (!$conn) {
            die("Connection Failed: " . mysqli_connect_error());
        }

        $query = "SELECT * FROM `users`";
        $result = $conn->query($query);
        $id = 0;
        $i = 0;
        while ($grammh = $result->fetch_assoc()) {
            if (isset($_POST['submit']) && ($_POST['submit']=='update') && $_POST['line'] == $i) {
                $i += 1;
                echo $_POST['line'].' '.$i;
                $id = $grammh['id'];
                $name = $grammh['name'];
                $surname = $grammh['surname'];
                $email = $grammh['loginame'];
                $password = $grammh['password'];
                $role = $grammh['role'];
                echo "<form action='..\pageconnectors\userconn.php' method='POST' enctype='multipart/form-data'>
                <td><p>$id</p></td>
                <td><input type='text' placeholder='Όνομα' name='name' value='$name' required /></td>
                <td><input type='text' placeholder='Επώνυμο' name='surname' value='$surname' required /></td>
                <td><input type='text' placeholder='Email' name='loginame' value='$email' required /></td>
                <td><input type='text' placeholder='Password' name='password' value='$password' required /></td>
                <td><select name='role' value='$role' required>
                        <option value='student'>student</option>
                        <option value='tutor'>tutor</option>
                    </select></td>

                <td>

                    <div class='buttons'>
                    <input type='hidden' value='$id' name='id' required />
                    <button type='submit' value='update' name='submit' class='btn btn-primary btn-sm' style='background: green;'>Done</button>
                    </div>
                </td>
            </form>
            ";
            } else {
                $id = $grammh['id'];
                $name = $grammh['name'];
                $surname = $grammh['surname'];
                $email = $grammh['loginame'];
                $password = $grammh['password'];
                $role = $grammh['role'];
                echo "<tbody>
            <tr>
                <td>" . $id . "</td>
                <td>" . $name . "</td>
                <td>" . $surname . "</td>
                <td>" . $email . "</td>
                <td>" . $password . "</td>
                <td>" . $role . "</td>

                <td>
                    <div class='buttons'>
                    <form action='..\creators\userhandl.php' method='POST' enctype='multipart/form-data'>
                    <input type='hidden' value='$id' name='id' required />
                    <input type='hidden' value='$i' name='line' required />
                    <button type='submit' value='update' name='submit' class='btn btn-primary btn-sm' >Update</button>
                    </form>
                    <form action='..\pageconnectors\userconn.php' method='POST' enctype='multipart/form-data'>
                    <input type='hidden' value='$id' name='id' required />
                    <button type='submit' value='delete' name='submit' class='btn btn-danger btn-sm' >Delete</button>
                    </form>
                    </div>
                </td>

            </tr>
        ";
        $i += 1;
            }
        }
        if(!isset($_POST['submit']))
        {
        $id += 1;
            echo "<tr>
            <form action='..\pageconnectors\userconn.php' method='POST' enctype='multipart/form-data'>
                <td><p>$id</p></td>
                <td><input type='text' placeholder='Όνομα' name='name' required /></td>
                <td><input type='text' placeholder='Επώνυμο' name='surname' required /></td>
                <td><input type='text' placeholder='Email' name='loginame' required /></td>
                <td><input type='text' placeholder='Password' name='password' required /></td>
                <td><select name='role' required>
                        <option value='student'>student</option>
                        <option value='tutor'>tutor</option>
                    </select></td>

                <td>

                    <div class='buttons'>
                    <input type='hidden' value='$id' name='id' required />
                        <button type='submit' value='upload' name='submit'
                            class='btn btn-primary btn-sm'>Add</button>
                    </div>
                </td>
            </form>
        </tr>";
        }?>
        </tbody>
    </table>
    <a href="../index.php">Πήγαινε πίσω στην αρχική σελίδα.</a>
</body>

</html>