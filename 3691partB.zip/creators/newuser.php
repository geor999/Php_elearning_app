<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="newwhw.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>Document</title>
</head>

<body>
  <form action="..\pageconnectors\anncconn.php" method="POST" enctype="multipart/form-data">
  <?php if(isset($_SESSION['updateuser']))
  {
    ?>
    <h1 id="top">Τροποποιήστε Χρήστη</h1>
    <div class="container">
    <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Όνομα</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το όνομα του χρήστη." name="name" required />
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Επώνυμο</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το επώνυμο του χρήστη." name="surname" required />
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Email</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το email του χρήστη." name="email" required>
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Password</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε τον κωδικό του χρήστη." name="password" required>
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Ρόλος</b></label>
      </div>
        <div class="inputs">
        <select name="role" required>
        <option value="student">student</option>
        <option value="tutor">tutor</option>
      </select>
      </div>
      </div>
    </div>
      <button type="submit" value="upload" name="submit" class="btn">Submit</button>
  </form>
  <?php
  }
  else { ?>
    <h1 id="top">Νέος Χρήστης</h1>
    <div class="container">
    <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Όνομα</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το όνομα του χρήστη." name="name" required />
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Επώνυμο</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το επώνυμο του χρήστη." name="surname" required />
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Email</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε το email του χρήστη." name="email" required>
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Password</b></label>
      </div>
        <div class="inputs">
      <input type="text" placeholder="Δώστε τον κωδικό του χρήστη." name="password" required>
      </div>
      </div>
      <div class="resize1">
        <div class="resize2">
      <label id="labels" type="text"><b>Ρόλος</b></label>
      </div>
        <div class="inputs">
        <select name="role" required>
        <option value="student">student</option>
        <option value="tutor">tutor</option>
      </select>
      </div>
      </div>
    </div>
      <button type="submit" value="upload" name="submit" class="btnn">Submit</button>
  </form>
  <?php } ?>
  <a href="../index.php">Go Back</a>
</body>

</html>