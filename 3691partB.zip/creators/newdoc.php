<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="newwhw.css" />
  <title>Διαχείριση Εγγράφων</title>
</head>

<body>
<?php
        session_start();
        if (!isset($_SESSION["loginame"])){
          header("location: ..\loginpage.php");
        }
    ?>
  <form action="..\pageconnectors\docconn.php" method="POST" enctype="multipart/form-data">
    <?php if (isset($_POST['submit']) && $_POST['submit'] == 'update') {
      $id = $_POST['id'];
      $title = $_POST['title'];
      $subject = $_POST['subject'];
      $docname = $_POST['docname'];
        echo"<h1 id='top'>Επεξεργασία Έγγραφου</h1>
        <div class='container'>
          <div class='resize1'>
            <div class='resize2'>
              <label id='labels' type='text'><b>Τίτλος</b></label>
            </div>
            <div class='inputs'>
            <input class='form-container' type='hidden' value='$id' name='id' required />
              <input class='form-container' type='text' value='$title' placeholder='Δώστε έναν τίτλο.' name='title' required />
            </div>
          </div>
          <div class='resize1'>
            <div class='resize2'>
              <label id='labels' type='text'><b>Περιγραφή</b></label>
            </div>
            <div class='inputs'>
              <input class='form-container' type='text' value='$subject' placeholder='Δώστε μια περιγραφή.' name='description' required />
            </div>
          </div>
          <div class='resize1'>
            <div class='resize2'>
              <label id='labels' type='text'><b>Έγγραφο(pdf,doc,docx)</b></label>
            </div>
            <div class='inputs'>
              <input class='form-container' type='file' value='../uploads/$docname' placeholder='Έγγραφο πρός εισαγωγή.' accept='.doc,.docx,.pdf'
                name='docfile' required>
            </div>
          </div>
        </div>
        <button type='submit' value='update' name='submit' class='btnn'>Submit</button>
      </form>";

    } else {
      echo
        "<h1 id='top'>Νέο Έγγραφο</h1>
    <div class='container'>
      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Τίτλος</b></label>
        </div>
        <div class='inputs'>
          <input class='form-container' type='text' placeholder='Δώστε έναν τίτλο.' name='title' required />
        </div>
      </div>
      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Περιγραφή</b></label>
        </div>
        <div class='inputs'>
          <input class='form-container' type='text' placeholder='Δώστε μια περιγραφή.' name='description' required />
        </div>
      </div>
      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Έγγραφο(pdf,doc,docx)</b></label>
        </div>
        <div class='inputs'>
          <input class='form-container' type='file' placeholder='Έγγραφο πρός εισαγωγή.' accept='.doc,.docx,.pdf'
            name='docfile' required>
        </div>
      </div>
    </div>
    <button type='submit' value='upload' name='submit' class='btnn'>Submit</button>
  </form>";
    } ?>
</body>

</html>