<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="newwhw.css" />
    <title>Διαχείριση Ανακοινώσεων</title>
</head>

<body>
    <?php
        session_start();
        if (!isset($_SESSION["loginame"])){
          header("location: ..\loginpage.php");
        }
    ?>
    <form action="..\pageconnectors\anncconn.php" method="POST" enctype="multipart/form-data">
        <?php
        if (isset($_POST['submit']) && $_POST['submit'] == 'update') {
            $id = $_POST['id'];
            $date = $_POST['date'];
            $subject = $_POST['subject'];
            $text = $_POST['text'];
            echo "<h1 id='top'>Νέα Ανακοίνωση</h1>
        <div class='container'>
        <div class='resize1'>
            <div class='resize2'>
        <label id='labels' type='text'><b>Θέμα</b></label>
        </div>
            <div class='inputs'>
            <input class='form-container' type='hidden' value='$id' name='id' required />
            <input class='form-container' type='hidden' value='$date' name='date' required />
             
        <input type='text' placeholder='Δώστε το θέμα της ανακοίνωσης.' value='$subject' name='description' required/>
        </div>
        </div>
    
        <div class='resize1'>
            <div class='resize2'>
        <label id='labels' type='text'><b>Κυρίως κείμενο</b></label>
        </div>
            <div class='inputs'>
        <input type='text' placeholder='Δώστε το περιεχόμενο της ανακοίνωσης.' value='$text' name='text' required>
        </div>
        </div>
        </div>
        <button type='submit' value='update' name='submit' class='btnn'>Submit</button>
        
      </form>";
        } else {
            echo "<h1 id='top'>Νέα Ανακοίνωση</h1>
    <div class='container'>
    <div class='resize1'>
        <div class='resize2'>
    <label id='labels' type='text'><b>Θέμα</b></label>
    </div>
        <div class='inputs'>
    <input type='text' placeholder='Δώστε το θέμα της ανακοίνωσης.' name='description' required/>
    </div>
    </div>

    <div class='resize1'>
        <div class='resize2'>
    <label id='labels' type='text'><b>Κυρίως κείμενο</b></label>
    </div>
        <div class='inputs'>
    <input type='text' placeholder='Δώστε το περιεχόμενο της ανακοίνωσης.' name='text' required>
    </div>
    </div>
    </div>
    <button type='submit' value='upload' name='submit' class='btnn'>Submit</button>
    
  </form>";
        } ?>
</body>

</html>