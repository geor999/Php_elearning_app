<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="newwhw.css" />
  <title>Διαχείριση Εργασιών</title>
</head>

<body>
<?php
        session_start();
        if (!isset($_SESSION["loginame"])){
          header("location: ..\loginpage.php");
        }
    ?>
  <form action="..\pageconnectors\hwconn.php" method="POST" enctype="multipart/form-data">
    
  <?php
  if (isset($_POST['submit']) && $_POST['submit'] == 'update') {
    $id = $_POST['id'];
    $goals = $_POST['goals'];
    $deliverables = $_POST['deliverables'];
    $name = $_POST['name'];
    $deadline = $_POST['deadline'];


    $goalsarr = str_split($goals);
    $goalsarray[4];
    $t = 0;
    foreach ($goalsarr as $char) {
      if ($char != '-') {
        $goalsarray[$t] .= $char;
      } else {
        $t += 1;
      }
    }


    $deliverablesarr = str_split($deliverables);
    $deliverablesarray[4];
    $t = 0;
    foreach ($deliverablesarr as $char) {
      if ($char != '-') {
        $deliverablesarray[$t] .= $char;
      } else {
        $t += 1;
      }
    }
    echo "
    <h1 id='top'>Change Homework</h1>
    <div id='container'>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Goals(at least one)</b></label>
        </div>
        <div class='inputs'>
          <input type='text' placeholder='First goal' value=$goalsarray[0] name='goal1' required />
          <input type='text' placeholder='Second goal'value=$goalsarray[1]  name='goal2' />
          <input type='text' placeholder='Third goal' value=$goalsarray[2]  name='goal3' />
          <input type='text' placeholder='Fourth goal' value=$goalsarray[3]  name='goal4' />
        </div>
      </div>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>File(pdf,doc,docx)</b></label>
        </div>
        <div class='inputs'>
        <input type='hidden' placeholder='Enter name' accept='.doc,.docx,.pdf' value='$id' name='id' required>
          <input type='file' placeholder='Enter name' accept='.doc,.docx,.pdf' value='$name' name='docfile' required>
        </div>
      </div>


      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Deliverables(at least one)</b></label>
        </div>
        <div class='inputs'>
          <input type='text' placeholder='First deliverable' value=$deliverablesarray[0] name='deliverable1' required />
          <input type='text' placeholder='Second deliverable' value=$deliverablesarray[1] name='deliverable2' />
          <input type='text' placeholder='Third deliverable' value=$deliverablesarray[2] name='deliverable3' />
          <input type='text' placeholder='Fourth deliverable' value=$deliverablesarray[3] name='deliverable4' />
        </div>
      </div>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Deadline</b></label>
        </div>
        <div class='inputs'>
          <input id='date' type='date' placeholder='Enter Deadline' value=$deadline name='deadline' required>
        </div>
      </div>
    </div>
    <button type='submit' value='update' name='submit' class='btnn'>Submit</button>
  </form>";
  }
  else
  {
    echo "
    <h1 id='top'>New Homework</h1>
    <div id='container'>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Goals(at least one)</b></label>
        </div>
        <div class='inputs'>
          <input type='text' placeholder='First goal' name='goal1' required />
          <input type='text' placeholder='Second goal' name='goal2' />
          <input type='text' placeholder='Third goal' name='goal3' />
          <input type='text' placeholder='Fourth goal' name='goal4' />
        </div>
      </div>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>File(pdf,doc,docx)</b></label>
        </div>
        <div class='inputs'>
          <input type='file' placeholder='Enter name' accept='.doc,.docx,.pdf' name='docfile' required>
        </div>
      </div>


      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Deliverables(at least one)</b></label>
        </div>
        <div class='inputs'>
          <input type='text' placeholder='First deliverable' name='deliverable1' required />
          <input type='text' placeholder='Second deliverable' name='deliverable2' />
          <input type='text' placeholder='Third deliverable' name='deliverable3' />
          <input type='text' placeholder='Fourth deliverable' name='deliverable4' />
        </div>
      </div>

      <div class='resize1'>
        <div class='resize2'>
          <label id='labels' type='text'><b>Deadline</b></label>
        </div>
        <div class='inputs'>
          <input id='date' type='date' placeholder='Enter Deadline' name='deadline' required>
        </div>
      </div>
    </div>
    <button type='submit' value='upload' name='submit' class='btnn'>Submit</button>
  </form>";
  }
?>
</body>

</html>