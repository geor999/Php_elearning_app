<head>
    <link rel="stylesheet" href="/topbutton/top.css">
    <script src="/topbutton/top.js" defer></script>
</head>

<body>
    <button id="topp" onclick="scrollto()">Top</button>
</body>