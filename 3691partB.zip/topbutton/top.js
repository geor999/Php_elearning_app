const btn = document.querySelector("#topp");

function scrollto()
{
    window.scrollTo(0,0);
}