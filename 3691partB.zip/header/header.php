<head>
    <link rel="stylesheet" href="header.css">
    <script src="/header/header.js" defer></script>
</head>

<body>
    <?php include '../connect.php';
    session_start();
    ?>
    <nav class="resizing-nav">
        <section class="navigation">
            <div onclick="redirect('index.php')" class="navigation-item">
                <h5 class="nav-text">Αρχική <br>Σελίδα</h5>
            </div>
            <div onclick="redirect('announcement.php')" class="navigation-item">
                <h5 class="nav-text">Ανακοινώσεις</h5>
            </div>
            <div onclick="redirect('communication.php')" class="navigation-item">
                <h5 class="nav-text">Επικοινωνία</h5>
            </div>
            <div onclick="redirect('documents.php')" class="navigation-item">
                <h5 class="nav-text">Έγγραφα<br> μαθήματος</h5>
            </div>
            <div onclick="redirect('homework.php')" class="navigation-item">
                <h5 class="nav-text">Εργασίες</h5>
            </div>
            <?php
            if (isset($_SESSION["loginame"])) {
                if ($_SESSION['role'] === 'tutor') {
                    echo "
            <a href='creators/userhandl.php' class='navigation-item'>
            <h5 class='nav-text'>Προσθήκη νέου χρήστη</h5>
                </a>";
                }
            }
            ?>
            <form method="post" class="navigation-item">
                <input class="logoutbtn" type="submit" name="logout" value="Logout"></input>
            </form>
        </section>
    </nav>

</body>