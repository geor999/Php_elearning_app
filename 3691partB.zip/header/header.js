function redirect(x)
{
    window.location.replace(x);
}